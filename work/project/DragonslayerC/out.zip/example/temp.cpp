#include <iostream>
#include <cstring>
using namespace std;

int main(){
    string temp = "ddddfa";
    cout << temp.find("f") << endl;
}
