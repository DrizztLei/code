#include <iostream>
#include <cstring>
using namespace std;
void test(){
cout<<"hello"<<endl;
cout << 2+44 << endl;
cout << (2+2+222+333)+2+222 << endl;
cout << 222+22222+2+2+222 << endl;
}
int main(int argc ,char ** argv){
test();
cout<<"Getsubofxandy:"<<2344+3<<endl;
test();
int aa = 1;
cout<<"ddd"<<endl;;
cout<<"a"<<endl;
cout << aa << endl;
cout << argc << endl << argv << endl;
string temp = "# definde " ;
cout << temp.find_first_of("define") << endl;
cout << temp.substr( 3 , 1) << endl;
199+3;
return 0;
}
