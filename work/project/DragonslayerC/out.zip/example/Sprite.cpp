#include <iostream>
using std::cout;
using std::cin;
using std::endl;


int main(int argc, char ** argv){

    return 0;
}
