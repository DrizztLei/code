#include <iostream>
#include <cstring>
using namespace std;

#define SWAP(A,B) A+B
# define ddd cout << "ddd " << endl;
#define a  cout << "a " << endl;

#define c 21345

#define AAA 2+2+SWAP(4,5)

#define demo(X,Y,AAA) X+Y+AAA

#define A SWAP(2,2)+222

#define AB(A,B,C) A*B*C

#define TEST(A,B) (A+B)+SWAP(2,222)

#define CCC SWAP(222,22222)+A

void test(){
#define dd cout << "hello" <<endl;
    dd
        cout << SWAP(2,44) << endl;
#define SUB(x,y) cout << "Get sub of x and y : " << x + y  << endl;
    cout << TEST(222,333) << endl;
    cout << CCC << endl;
}

#define X 100


#define SWAP(X,Y) cout << X + Y << endl;

int main(int argc ,char ** argv){
    test();
    SUB(2344,3)
        test();
    int aa = 1;
    ddd;
    a
#undef a
        cout << aa << endl;
    cout << argc << endl << argv << endl;
    string temp = "# definde " ;
    cout << temp.find_first_of("define") << endl;
    cout << temp.substr( 3 , 1) << endl;
    SWAP(199,3);
    return 0;
}
