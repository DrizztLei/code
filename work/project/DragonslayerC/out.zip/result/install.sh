g++ -fpermissive MacroFind.cpp 	Scanner.h -o macro && sudo cp -rf macro /usr/bin &&echo "Install finished , run the command macro ." && rm macro && sudo chmod +x /usr/bin/macro

