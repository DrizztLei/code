//package sdu.embedded.SonicCollector;
//
//
//import android.support.v4.app.Fragment;
//import android.support.v4.app.FragmentStatePagerAdapter;
//
//
//public class PictureSlidePagerAdapter extends FragmentStatePagerAdapter {
//
//    private static final int NUM_PIC = 11;
//
//    public PictureSlidePagerAdapter(android.support.v4.app.FragmentManager fragmentManager) {
//        super(fragmentManager);
//    }
//
//    @Override
//    public Fragment getItem(int arg0) {
//        return new PictureSlideFragment(arg0);
//    }
//
//    @Override
//    public int getCount() {
//        return NUM_PIC;
//    }
//}
