package com.hillsidewatchers.sdu.sonicoperator.Analyzer;
public interface svm_print_interface
{
	public void print(String s);
}
