package sdu.embedded.Sonic.core;

public class ManualTest {

}
