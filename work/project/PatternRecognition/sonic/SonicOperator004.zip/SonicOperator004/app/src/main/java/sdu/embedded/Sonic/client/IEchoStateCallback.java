package sdu.embedded.Sonic.client;

public interface IEchoStateCallback {

}
