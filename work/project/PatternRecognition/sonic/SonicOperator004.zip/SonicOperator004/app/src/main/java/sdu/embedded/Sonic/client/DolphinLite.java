package sdu.embedded.Sonic.client;

public class DolphinLite implements IDolphin {

}
