#include "debug.h"

Debug::Debug()
{

}
