#include "url.h"
/*
Url* Url::url = NULL;

Url* Url::getInstead(QString path = ""){
  if(Url::url == NULL){
      Url::url = new Url(path);
    }
  return Url::url;
}

Url* Url::setInstead(QString path){
  Url::url = NULL;
  Url::url = new Url(path);
  return Url::url;
}
*/
