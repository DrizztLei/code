#include "label.h"

void Label::get(LABEL flag){
  if(flag == LABEL::LEFT){

    }else if(flag == LABEL::RIGHT){

    }else {
      return NULL;
    }
}
