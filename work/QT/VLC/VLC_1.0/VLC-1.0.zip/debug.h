#ifndef DEBUG_H
#define DEBUG_H
#include <QDebug>

class Debug : public QDebug
{
public:
  Debug();
};

#endif // DEBUG_H
