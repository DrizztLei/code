#ifndef LIST_H
#define LIST_H
#include <QList>

class List : public QList
{
public:
  List();
};

#endif // LIST_H
