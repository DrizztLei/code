#include "mediaplayer.h"

MediaPlayer::MediaPlayer()
{

}
