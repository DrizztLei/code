#include "slider.h"

Slider::Slider()
{

}
