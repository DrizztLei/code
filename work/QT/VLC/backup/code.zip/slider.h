#ifndef SLIDER_H
#define SLIDER_H
#include <QSlider>

class Slider : public QSlider
{
public:
  Slider();
};

#endif // SLIDER_H
