#ifndef VIDEOWIDGET_H
#define VIDEOWIDGET_H
#include <QVideoWidget>

class VideoWidget : public QVideoWidget
{
public:
  VideoWidget();
};

#endif // VIDEOWIDGET_H
