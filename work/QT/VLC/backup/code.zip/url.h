#ifndef URL_H
#define URL_H
#include <QUrl>

class Url : public QUrl
{

public:
  Url();
};

#endif // URL_H
