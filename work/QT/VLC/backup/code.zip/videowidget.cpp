#include "videowidget.h"

VideoWidget::VideoWidget()
{

}
