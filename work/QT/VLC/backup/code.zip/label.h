#ifndef LABEL_H
#define LABEL_H
#include <QLabel>

class Label : public QLabel
{
public:
  Label();
};

#endif // LABEL_H
