#include "fileinfo.h"

FileInfo::FileInfo()
{

}
