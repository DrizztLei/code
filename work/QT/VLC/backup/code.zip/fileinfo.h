#ifndef FILEINFO_H
#define FILEINFO_H
#include <QFileInfo>

class FileInfo : public QFileInfo
{
public:
  FileInfo();
};

#endif // FILEINFO_H
