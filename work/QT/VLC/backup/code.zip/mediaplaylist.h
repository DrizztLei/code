#ifndef MEDIAPLAYLIST_H
#define MEDIAPLAYLIST_H
#include <QMediaPlaylist>

class MediaPlaylist : public QMediaPlaylist
{
public:
  MediaPlaylist();
};

#endif // MEDIAPLAYLIST_H
