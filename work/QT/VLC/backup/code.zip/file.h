#ifndef FILE_H
#define FILE_H
#include <QFile>

class File : public QFile
{

public:
  File();
};

#endif // FILE_H
