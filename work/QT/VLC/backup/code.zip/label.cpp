#include "label.h"

Label::Label()
{

}
