#ifndef MEDIAPLAYER_H
#define MEDIAPLAYER_H
#include <QMediaPlayer>

class MediaPlayer : public QMediaPlayer
{
public:
  MediaPlayer();
};

#endif // MEDIAPLAYER_H
