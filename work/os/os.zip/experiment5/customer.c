#ifndef _CUS_CPP
#define _CUS_CPP

#include <stdio.h>
#include <string.h>
#include <sys/ipc.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <sys/sem.h>
#include <sys/msg.h>
#include <unistd.h>
#include <stdlib.h>
#include <signal.h>
#include <sys/msg.h>
#include <error.h>
#include <sys/wait.h>
#include <math.h>
#include <time.h>

#define SIZE 1024
#define NUM 4

union semun{
    int val;
    struct semid_ds * buf;
    unsigned short * array;
};

struct msgbuf{
    long type;
    char mtext[1];
    int * id;
};

key_t get_key( char const  * const address , int value){
    return ftok(address , value);
}

void charge();

int P(int semid , int index);

int V(int semid , int index);

void show(int * address , int limit){
    for(int i = 0 ; i < limit ; i++){
        printf("Get the value %d for %d .\n" , i , address[i]);
    }
}

int get_random(){
    return random() % 3;
}

int main(int argc , char ** argv){

    key_t key_shm = get_key("./" , 0x12);
    key_t key_sem = get_key("./" , 0x13);
    key_t key_sofa = get_key("./" , 0x14);
    key_t key_wait = get_key("./" , 0x15);
    key_t key_charge = get_key("./" , 0x16);

    int shmid , semid , msg_sofa , msg_wait , msg_charge;

    shmid = shmget(key_shm , 4 , IPC_CREAT | IPC_EXCL);
    if(shmid < 0){
        perror("The shm not found.");
    }
    semid = semget(key_sem , 4 , IPC_CREAT | IPC_EXCL);
    if(semid < 0){
        perror("The sem not found.");
    }
    msg_sofa = msgget(key_sofa , IPC_CREAT | IPC_EXCL);
    if(msg_sofa < 0){
        perror("Error for msgget.");
    }
    msg_wait = msgget(key_wait , IPC_CREAT | IPC_EXCL);
    if(msg_wait < 0){
        perror("Error for msgget.");
    }
    msg_charge = msgget(key_charge , IPC_CREAT | IPC_EXCL);
    if(msg_charge < 0){
        perror("Error for msgget.");
    }

    union semun sender;
    sender.val = 1;
    for(int i = 0 ; i < NUM ; i++){
        if(semctl(semid , i , SETVAL , sender)){
            printf("catch the info for %d.\n" , i);
            perror("Error for set the value .");
            return EXIT_FAILURE;
        }
    }

    pid_t son = fork();
    if(son < 0){
        perror("Error for fork.");
        return EXIT_FAILURE;
    }else if(son == 0){
        //code for son.
        while(1){

        }
        return EXIT_FAILURE;
    }else{
        //code for father
        while(1){

        }
        return EXIT_FAILURE;
    }

/*
  pid_t son = fork();
  if(son == 0){
  // code for the son .
  int x = 0;
  write(_pipe[1] , &x , sizeof(int));
  struct msgbuf buf;
  buf.mtext[0] = 'U';
  while(1){
  sleep(5);
  P(semid , NUM - 1);
  {
  printf("son's process\n");
  if(msgrcv(msg_sofa, &buf, sizeof(char) + sizeof(int), 0, IPC_NOWAIT)){
  char character = buf.mtext[0];
  x = get_random();
  if(character == 'U'){
  //code for generated the random product.
  P(semid , x);
  printf("generated the product random.\n");
  int * result = (int *)shmat(shmid, NULL, 0);
  if((int)(result) == -1){
  perror("Error for shmat .");
  return EXIT_FAILURE;
  }
  result[x] ++;
  show(result , 3);
  if(shmdt(result)){
  perror("Error for shmdt.");
  return EXIT_FAILURE;
  }
  V(semid,x);
  }else{
  //code for generated the specific product.
  switch (character){
  case 'T':{
  P(semid , 0);
  int * result = (int *)shmat(shmid, NULL, 0);
  if((int)(result) == -1){
  perror("Error for shmat .");
  return EXIT_FAILURE;
  }
  printf("generated the product T.\n");
  result[0] ++;
  show(result , 3);
  if(shmdt(result)){
  perror("Error for shmdt in T.");
  return EXIT_FAILURE;
  }
  V(semid,0);
  break;
  }
  case 'P':{
  P(semid,1);
  int * result = (int *)shmat(shmid, NULL, 0);
  if((int)(result) == -1){
  perror("Error for shmat .");
  return EXIT_FAILURE;
  }
  printf("generated the product P.\n");
  result[1] ++;
  show(result , 3);
  if(shmdt(result)){
  perror("Error for shmdt in P.");
  return EXIT_FAILURE;
  }
  V(semid,1);
  break;
  }
  case 'G':{
  P(semid,2);
  int * result = (int *)shmat(shmid, NULL, 0);
  if((int)(result) == -1){
  perror("Error for shmat .");
  return EXIT_FAILURE;
  }
  printf("generated the product G.\n");
  result[2] ++;
  show(result , 3);
  if(shmdt(result)){
  perror("Error for shmdt in G.");
  return EXIT_FAILURE;
  }
  V(semid,2);
  break;
  }
  default : break;
  }
  }
  }else{
  perror("Error for msgrcv .");
  return EXIT_FAILURE;
  }
  }
  V(semid , NUM - 1);
  }
  }else if(son > 0){
  // code for the father.
  int x = 0;
  read(_pipe[0] , &x , sizeof(int));
  struct msgbuf buf ;
  buf.mtext[0] = 'U';
  printf("Get the info\n");
  while(1){
  x = get_random();
  sleep(5);
  P(semid , NUM - 1);
  {
  printf("father's process\n");
  if(msgrcv(msg_sofa, &buf, sizeof(char) + sizeof(int), 0, IPC_NOWAIT)){
  char character = buf.mtext[0];
  //if(strcmp(buf.mtext , "U") == 0){
  //code for generated the random product.
  x = get_random();
  int * result = (int *)shmat(shmid, NULL, 0);
  if(character == 'U'){
  if((int)(result) == -1){
  perror("Error for shmat .");
  return EXIT_FAILURE;
  }
  printf("generated the product random.\n");
  result[x] ++;
  show(result , 3);
  if(shmdt(result)){
  perror("Error for shmdt.");
  return EXIT_FAILURE;
  }
  }else{
  //code for generated the specific product.
  switch (character){
  case 'T':{
  if((int)(result) == -1){
  perror("Error for shmat .");
  return EXIT_FAILURE;
  }
  printf("generated the product T.\n");
  result[0] ++;
  show(result , 3);
  if(shmdt(result)){
  perror("Error for shmdt in T.");
  return EXIT_FAILURE;
  }
  break;
  }
  case 'P':{
  if((int)(result) == -1){
  perror("Error for shmat .");
  return EXIT_FAILURE;
  }
  printf("generated the product P.\n");
  result[1] ++;
  show(result , 3);
  if(shmdt(result)){
  perror("Error for shmdt in P.");
  return EXIT_FAILURE;
  }
  break;
  }
  case 'G':{
  if((int)(result) == -1){
  perror("Error for shmat .");
  return EXIT_FAILURE;
  }
  printf("generated the product G.\n");
  result[2] ++;
  show(result , 3);
  if(shmdt(result)){
  perror("Error for shmdt in G.");
  return EXIT_FAILURE;
  }
  break;
  }
  default : break;
  }
  }
  }else{
  perror("Error for msgrcv .");
  return EXIT_FAILURE;
  }
  }
  V(semid , NUM - 1);
  }
  if(shmctl(shmid , IPC_RMID , 0)){
  perror("Error for delete the shm failed.");
  return EXIT_FAILURE;
  }
  if(semctl(semid , IPC_RMID , 0)){
  perror("Error for delete the sem failed.");
  return EXIT_FAILURE;
  }
  if(msgctl(msg_sofa , IPC_RMID ,0)){
  perror("Error for delete the msg_soft failed");
  return EXIT_FAILURE;
  }
  if(msgctl(msg_wait , IPC_RMID ,0)){
  perror("Error for delete the msg_wait failed");
  return EXIT_FAILURE;
  }
  }else{
  perror("Error for create the pid failed.");
  return EXIT_FAILURE;
  }
*/
    return EXIT_SUCCESS;
}

int P(int semid , int index){
    struct sembuf buf = {index , -1 , SEM_UNDO};
    if(semop(semid , &buf , 1)){
        perror("Error for operation P .");
        return EXIT_FAILURE;
    }
    printf("Get the info provider coming.\n");
    return EXIT_SUCCESS;
}

int V(int semid , int index){
    struct sembuf buf = {index , 1 , SEM_UNDO};
    printf("Get the info provider quiet.\n");
    if(semop(semid , &buf , 1)){
        perror("Error for operation V .");
        return EXIT_FAILURE;
    }
    return EXIT_SUCCESS;
}

void charge(){

}

#endif
