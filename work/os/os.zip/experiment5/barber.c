#ifndef _BAR_CPP
#define _BAR_CPP

#include <stdio.h>
#include <sys/ipc.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <sys/sem.h>
#include <sys/msg.h>
#include <unistd.h>
#include <stdlib.h>
#include <signal.h>
#include <sys/msg.h>
#include <error.h>
#include <sys/wait.h>
#include <stdbool.h>
#include <string.h>

#define NUM 4

int  _pipe[2];

int P(int semid , int index);

int V(int semid , int index);

void barbe();

void charge();

void rest();

void move(key_t key_sofa , key_t key_wait);

key_t get_key(char const * const address , int code){
    return ftok(address , code);
}

struct msgbuf{
    long type;
    char mtext[1];
    int id;
};

int const size = sizeof(char) + sizeof(int);

int main(int argc , char ** argv){

    // The grammar for creating the share memory.

    key_t key_shm = get_key("./" , 0x12);
    key_t key_sem = get_key("./" , 0x13);
    key_t key_sofa = get_key("./" , 0x14);
    key_t key_wait = get_key("./" , 0x15);
    key_t key_charge = get_key("./" , 0x16);

    int shmid , semid , msg_sofa , msg_wait , msg_charge;
    while(1){
        sleep(2);
        shmid = shmget(key_shm , 0 , IPC_CREAT);
        if(shmid < 0){
            perror("The shm not found . \n");
        }
        semid = semget(key_sem , 0 , IPC_CREAT);
        if(semid < 0){
            perror("The sem not found . \n .");
        }
        msg_sofa = msgget(key_sofa , IPC_CREAT);
        if(msg_sofa < 0){
            perror("Error for msgget .");
        }
        msg_wait = msgget(key_wait , IPC_CREAT);
        if(msg_wait < 0){
            perror("Error for msgget .");
        }
        msg_charge = msgget(key_charge , IPC_CREAT);
        if(msg_charge < 0){
            perror("Error for msgget .");
        }
        if(shmid > 0 && semid > 0 && msg_sofa > 0 && msg_wait > 0 && msg_charge > 0) {
            break;
        }
    }
    pid_t A = fork();
    if(A < 0){
        perror("create the t fork() error.");
        return EXIT_FAILURE;
    }else if(A == 0){
        // code for A
        /*
          while(1){
          bool barber_flag = true , wait_flag = true;
          struct msgbuf buf;
          buf.id = 0;
          //send msg to mqueue
          printf("barber A is waiting .\n");
          buf.id = 0;
          if(msgrcv(msg_sofa, &buf, size , 0 , IPC_NOWAIT)){
          perror("Error for msgsnd .");
          return EXIT_FAILURE;
          }
          if(buf.id != 0) barber_flag = false;
          if(barber_flag){
          printf("Error for get the msg.id.\n");
          }else{
          printf("Get the value %d for pid.\n" , buf.id);
          move(key_sofa , key_wait);
          }
          barbe("A" , buf.id);
          P(semid , 1);
          {
          buf.id = 0;
          if(msgrcv(msg_charge , &buf , size , 0 , IPC_NOWAIT)){
          perror("Error for msgrcv . \n");
          return EXIT_FAILURE;
          }
          if(buf.id != 0) wait_flag = false;
          charge("A", buf.id);
          }
          V(semid , 1);
          if(barber_flag && wait_flag){
          rest("A");
          }
          }
        */
        signal(SIGCONT, rest);
        while(1){
            struct msgbuf buf;
            buf.id = 0;
            if(msgrcv(msg_sofa, &buf, size, 0, IPC_NOWAIT)){
                perror("Error for msgrcv .");
                return EXIT_FAILURE;
            }
            if(buf.id == 0){
                rest();
            }else{
                move(key_sofa , key_wait);
                barbe("A", buf.id);
                P(semid , 0);
                charge();
                V(semid , 0);
            }
        }
    }else{
        /*
          pid_t B = fork();
          if(B < 0){
          perror("create the G fork() error.");
          return EXIT_FAILURE;
          }else if(B == 0){
          // code for B
          bool flag = true;
          while(1){
          sleep(2);
          struct msgbuf buf;
          buf.mtext[0] = 'B';
          buf.id = 0;
          P(semid , 2);
          {
          int * address = (int *)shmat(shmid, NULL, 0);
          if((int)(address) == -1){
          perror("Error for shmat.");
          return EXIT_FAILURE;
          }
          if(address[2] <= 0){
          //send msg to mqueue
          if(flag){
          if(msgsnd(msg_sofa, &buf, sizeof(char) + sizeof(int), IPC_NOWAIT)){
          perror("Error for msgsnd .");
          return EXIT_FAILURE;
          }
          flag = !flag;
          }else{
          sleep(1);
          }
          }else{
          address[0] --;
          flag = true;
          }
          if(shmdt(address)){
          perror("Error for shmdt .");
          return EXIT_FAILURE;
          }
          }
          V(semid , 2);
          }
          }else{
          // code for C
          bool flag = true;
          while(1){
          sleep(2);
          struct msgbuf buf;
          buf.mtext[0] = 'C';
          buf.id = 0;
          P(semid , 1);
          {
          int * address = (int *)shmat(shmid, NULL, 0);
          if((int)(address) == -1){
          perror("Error for shmat.");
          return EXIT_FAILURE;
          }
          if(address[1] <= 0){
          //send msg to mqueue
          if(flag){
          if(msgsnd(msg_sofa, &buf, sizeof(char) + sizeof(int), IPC_NOWAIT)){
          perror("Error for msgsnd .");
          return EXIT_FAILURE;
          }
          flag = !flag;
          }else{
          sleep(1);
          }
          }else{
          address[1] --;
          flag = true;
          }
          if(shmdt(address)){
          perror("Error for shmdt .");
          return EXIT_FAILURE;
          }
          }
          V(semid , 1);
          }
          }
        */
    }
    return EXIT_SUCCESS;
}

int P(int semid , int index){
    struct sembuf buf = {index , -1 , SEM_UNDO};
    if(semop(semid , &buf , 1)){
        perror("Error for operation P .");
        return EXIT_FAILURE;
    }
    printf("Get the info for smoker coming. \n");
    return EXIT_SUCCESS;
}

int V(int semid , int index){
    struct sembuf buf = {index , 1 , SEM_UNDO};
    printf("Get the info for smoker quiet. \n");
    if(semop(semid , &buf , 1)){
        perror("Error for operation V .");
        return EXIT_FAILURE;
    }
    return EXIT_SUCCESS;
}

void barbe(char * string , int id){

}

void charge(){

}

void rest(){
    return ;
}

void move(key_t key_sofa , key_t key_wait){

}

#endif
