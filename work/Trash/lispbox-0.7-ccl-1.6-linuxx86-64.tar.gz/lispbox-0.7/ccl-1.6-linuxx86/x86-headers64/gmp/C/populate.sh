#!/bin/sh
h-to-ffi.sh -m64 /usr/include/gmp.h
