#!/bin/sh
h-to-ffi.sh -m64 -I/usr/include/GNUstep /usr/include/GNUstep/Cocoa/Cocoa.h
